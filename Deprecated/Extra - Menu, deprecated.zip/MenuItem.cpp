/*
	GUIWidgets - MenuItem
	 The default widgets for use in GUICore.
	 author: WolfgangKurz

	Item of Menu class
	need to use Menu
*/

#include "MenuItem.hpp"
#include "Menu.hpp"
#include "MenuPopup.hpp"

/*
class MenuItemButtonClick : public GUIMouseEvent {
public:
	virtual long Event(GUIObject *sender, GUIMouse, GUIShift, int, int){
		MenuItem *item = *((MenuItem**)sender->extra);
		Menu *menu = (Menu*)item->getRoot();

		if(item->getChildCount()==0){ // Single Menu
			if(menu){
				menu->popupClose();
			}else{
				MenuItem *parent = item;
				while(parent->getParent()!=(MenuItem*)NULL) parent = parent->getParent();
				parent->popupClose();
			}

			if(item->onMenuClick) item->onMenuClick->Event(menu, item->getKey());
			if(menu && menu->onMenuClick) menu->onMenuClick->Event(menu, item->getKey());
		}
		item->invalidate();
		return 0;
	}
};
*/

MenuItem::MenuItem(wchar_t *key, wchar_t *text){
	this->popup = new MenuPopup(this);

	this->onMenuClick = (GUIMenuEventP)NULL;

	this->parent = (MenuItem*)NULL;
	this->root = (Menu*)NULL;

	this->backColor = 0x000000;
	this->activeBackColor = 0x444444;
	this->textColor = 0xFFFFFF;
	this->hoverColor = -1; // transparent
	this->enabled = 1;

	this->childCount = 0;
	this->childs = (MenuItem**)NULL;

	this->text = (wchar_t*)NULL;
	this->setText(text);

	int len = wcslen(key);
	this->key = new wchar_t[len+1];
	wcscpy_s(this->key, len+1, key);
}
MenuItem::MenuItem(wchar_t *key, wchar_t *text, MenuItem *parent){
	this->popup = new MenuPopup(this);

	this->onMenuClick = (GUIMenuEventP)NULL;

	this->parent = parent;
	this->root = (Menu*)NULL;

	this->backColor = 0x000000;
	this->activeBackColor = 0x444444;
	this->textColor = 0xFFFFFF;
	this->hoverColor = -1; // transparent
	this->enabled = 1;

	this->childCount = 0;
	this->childs = (MenuItem**)NULL;

	this->text = (wchar_t*)NULL;
	this->setText(text);

	int len = wcslen(key);
	this->key = new wchar_t[len+1];
	wcscpy_s(this->key, len+1, key);
}
MenuItem::~MenuItem(){
	if(this->childs!=(MenuItem**)NULL){
		for(int i=0; i<this->childCount; i++)
			delete this->childs[i];
		delete[] this->childs;
	}
	if(this->key!=(wchar_t*)NULL) delete[] this->key;
	if(this->text!=(wchar_t*)NULL) delete[] this->text;
	if(this->popup!=(GUIWindow*)NULL) delete this->popup;

	if(this->onMenuClick) delete this->onMenuClick;
}

void MenuItem::prepare(){
	int y=0, tw = 0;
	HDC hDC = GetDC(HWND_DESKTOP);
	HFONT font = (HFONT)SelectObject(hDC, this->getFont());
		const wchar_t *text;

		for(int i=0; i<this->childCount; i++){
			MenuItem *child = this->childs[i];
			SIZE sz;

			text = child->getText();
			if( wcslen(text)==1 && text[0]==L'-' ){
				sz.cx = 0;
				sz.cy = -5;
			}else if( child->getChildCount()>0 ){
				wchar_t *ttext = new wchar_t[wcslen(text)+3+1];
					wcscpy_s(ttext, wcslen(text)+3+1, text);
					wcscat_s(ttext, wcslen(text)+3+1, L"  \x25B8");
					GetTextExtentPoint32(hDC, ttext, wcslen(ttext), &sz);
				delete[] ttext;
			}else{
				GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
			}

			tw = (tw<sz.cx) ? sz.cx : tw;
			y += sz.cy+8;
		}
		tw += 12;
	SelectObject(hDC, font);
	ReleaseDC(HWND_DESKTOP, hDC);

	this->popup->resize(tw+2, y+2);
}

MenuItem* MenuItem::setFont(const wchar_t *fontName, int fontSize, int weight){
	this->popup->setFont(fontName, fontSize, weight);
	for(int i=0; i<this->childCount; i++) this->childs[i]->setFont(fontName, fontSize, weight);
	this->prepare();
	this->invalidate();
	return this;
}
MenuItem* MenuItem::setFont(HFONT font){
	this->popup->setFont(font);
	for(int i=0; i<this->childCount; i++) this->childs[i]->setFont(font);
	this->prepare();
	this->invalidate();
	return this;
}
HFONT MenuItem::getFont(){
	return this->popup->getFont();
}

MenuItem* MenuItem::invalidate(){
	this->popup->invalidate();
	return this;
}

MenuItem* MenuItem::setEnabled(int enabled){
	this->enabled = enabled;
	return this;
}
int MenuItem::getEnabled(){
	return this->enabled;
}

MenuItem* MenuItem::setBackColor(int color){
	this->popup->setBackColor(color);
	this->backColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setBackColor(color);
	return this;
}
int MenuItem::getBackColor(){
	return this->backColor;
}

MenuItem* MenuItem::setActiveBackColor(int color){
	this->popup->setActiveBackColor(color);
	this->activeBackColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setActiveBackColor(color);
	return this;
}
int MenuItem::getActiveBackColor(){
	return this->activeBackColor;
}

MenuItem* MenuItem::setHoverColor(int color){
	this->popup->setHoverColor(color);
	this->hoverColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setHoverColor(color);
	return this;
}
int MenuItem::getHoverColor(){
	return this->hoverColor;
}

MenuItem* MenuItem::setTextColor(int color){
	this->popup->setTextColor(color);
	this->textColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setTextColor(color);
	return this;
}
int MenuItem::getTextColor(){
	return this->textColor;
}

MenuItem* MenuItem::setBorderColor(int color){
	this->popup->setBorderColor(color);
	return this;
}
int MenuItem::getBorderColor(){
	return this->popup->getBorderColor();
}

MenuItem* MenuItem::setRoot(GUIObject *root){
	this->root = root;
	return this;
}
GUIObject* MenuItem::getRoot(){
	return this->root;
}

MenuItem* MenuItem::getParent(){
	return this->parent;
}

int MenuItem::getChildCount(){
	return this->childCount;
}
MenuItem* MenuItem::getChild(int index){
	if(index<0 || index>=this->childCount) return (MenuItem*)NULL;
	return this->childs[index];
}

MenuItem* MenuItem::addChild(wchar_t *key, wchar_t *text){
	MenuItem **copy = new MenuItem*[this->childCount+1];
	MenuItem *item = new MenuItem(key, text, this);

	if(this->childs!=(MenuItem**)NULL){
		memcpy((void*)copy, this->childs, sizeof(MenuItem*)*this->childCount);
		delete[] this->childs;
	}

	item->setFont(this->getFont())
		->setBackColor(this->getBackColor())
		->setActiveBackColor(this->getActiveBackColor())
		->setHoverColor(this->getHoverColor())
		->setTextColor(this->getTextColor())
		->setBorderColor(this->getBorderColor())
		->setRoot(this->root);

	copy[this->childCount] = item;
	this->childCount++;
	this->childs = copy;

	this->prepare();
	return item;
}
MenuItem* MenuItem::addChild(wchar_t *key, wchar_t *text, int index){
	if(index<0 || index>this->childCount) return (MenuItem*)NULL;

	MenuItem **copy = new MenuItem*[this->childCount+1];
	MenuItem *item = new MenuItem(key, text, this);

	if(index>0) memcpy(copy, this->childs, sizeof(MenuItem*)*index);
	if(index<this->childCount) memcpy(&copy[index+1], this->childs+index, sizeof(MenuItem*)*(this->childCount-index));

	if(this->childs!=(MenuItem**)NULL) delete[] this->childs;
	
	item->setFont(this->getFont())
		->setBackColor(this->getBackColor())
		->setActiveBackColor(this->getActiveBackColor())
		->setHoverColor(this->getHoverColor())
		->setTextColor(this->getTextColor())
		->setBorderColor(this->getBorderColor())
		->setRoot(this->root);

	copy[index] = item;
	this->childCount++;
	this->childs = copy;

	this->prepare();
	return item;
}
MenuItem* MenuItem::removeChild(int index){
	if(index<0 || index>=this->childCount) return this;

	MenuItem **copy = new MenuItem*[this->childCount-1];

	if(index>0) memcpy(copy, this->childs, sizeof(MenuItem*)*index);
	memcpy(copy+index, this->childs+index+1, sizeof(MenuItem*)*(this->childCount-index-1));

	delete[] this->childs;

	this->childCount--;
	this->childs = copy;

	return this;
}

const wchar_t* MenuItem::getKey(){
	return (const wchar_t*)this->key;
}
const wchar_t* MenuItem::getText(){
	return (const wchar_t*)this->text;
}
MenuItem* MenuItem::setText(wchar_t *text){
	if(this->text!=(wchar_t*)NULL) delete[] this->text;

	int len = wcslen(text);
	this->text = new wchar_t[len+1];
	wcscpy_s(this->text, len+1, text);

	return this;
}

MenuItem* MenuItem::popupShow(int x, int y){
	this->popup->move(x, y)
		->show(SW_SHOWNA);
	return this;
}
MenuItem* MenuItem::popupClose(){
	this->popup->hide();

	for(int i=0; i<this->childCount; i++)
		this->childs[i]->popupClose();
	return this;
}
int MenuItem::popupVisible(){
	return IsWindowVisible(this->popup->getHWND());
}
int MenuItem::popupTest(){
	for(int i=0; i<this->childCount; i++)
		if(this->childs[i]->popupTest()>0) return 1;

	POINT pt; GetCursorPos(&pt);
	HWND hWnd = WindowFromPoint(pt);
	//while( GetParent(hWnd)!=(HWND)NULL ) hWnd = GetParent(hWnd);
	if(hWnd==this->popup->getHWND()) return 2;
	return 0;
}
int MenuItem::popupCheck(){
	if( this->popupTest()==0 ){
		this->popupClose();
		for(int i=0; i<this->childCount; i++)
			this->childs[i]->popupClose();
		return 0;
	}else{
		for(int i=0; i<this->childCount; i++)
			this->childs[i]->popupCheck();
	}
	return 1;
}
