/*
	GUIWidgets - MenuPopup
	 The default widgets for use in GUICore.
	 author: WolfgangKurz

	Popup window of Menu
*/

#include "MenuPopup.hpp"
#include "MenuItem.hpp"
#include "Menu.hpp"
#include "GUIValues.h"

MenuPopup::MenuPopup(void *item) : GUIWindow(WS_POPUP, WS_EX_NOACTIVATE | WS_EX_TOPMOST, (HWND)NULL, 1){
	this->item = item;

	this->backColor = 0x000000;
	this->activeBackColor = 0x444444;
	this->textColor = 0xFFFFFF;
	this->hoverColor = -1; // transparent

	this->index = -1;
	this->state = 0;
}
void* MenuPopup::getItem(){
	return this->item;
}

MenuPopup* MenuPopup::setBackColor(int color){
	this->backColor = color;
	return this;
}
int MenuPopup::getBackColor(){
	return this->backColor;
}

MenuPopup* MenuPopup::setActiveBackColor(int color){
	this->activeBackColor = color;
	return this;
}
int MenuPopup::getActiveBackColor(){
	return this->activeBackColor;
}

MenuPopup* MenuPopup::setHoverColor(int color){
	this->hoverColor = color;
	return this;
}
int MenuPopup::getHoverColor(){
	return this->hoverColor;
}

MenuPopup* MenuPopup::setTextColor(int color){
	this->textColor = color;
	return this;
}
int MenuPopup::getTextColor(){
	return this->textColor;
}

MenuPopup* MenuPopup::setBorderColor(int color){
	this->borderColor = color;
	return this;
}
int MenuPopup::getBorderColor(){
	return this->borderColor;
}

LRESULT MenuPopup::handleMessage(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam){
	switch(Msg){
		case WM_LBUTTONDOWN:{
			MenuItem *item = (MenuItem*)this->item;
			POINTS pts = MAKEPOINTS(lParam);
			int prev = this->state;
			this->state = 0;

			if(pts.x<0 || pts.y<0 || pts.x>=this->getWidth() || pts.y>=this->getHeight()){
				ReleaseCapture();

				if( item->popupTest()==0 ){
					this->index = -1;
					this->invalidate();
					item->popupClose();
				}
				break;
			}

			if(this->index>=0){
				this->state = 1;

				if(item->getChild(this->index)->getChildCount()>0){
					int y = 0;
					HDC hDC = GetDC(hWnd);
					HFONT font = (HFONT)SelectObject(hDC, this->getFont());
						for(int i=0; i<this->index; i++){
							const wchar_t *text = item->getChild(i)->getText();
							SIZE sz;

							GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
							y += sz.cy+8;
						}

						const wchar_t *text = item->getChild(this->index)->getText();
						SIZE sz;
						GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
					SelectObject(hDC, font);
					ReleaseDC(hWnd, hDC);

					POINT pt = {this->getWidth(), y};
					ClientToScreen(this->hWnd, &pt);

					MenuItem *child = item->getChild(this->index);
					child->popupShow(pt.x-1, pt.y);
				}
			}

			if(this->state!=prev) this->invalidate();
			break;}
		case WM_LBUTTONUP:{
			MenuItem *item = (MenuItem*)this->item;
			int prev = this->state;
			this->state = 0;

			if(this->index>=0){
				MenuItem *child = item->getChild(this->index);
				if(child->getChildCount()==0){
					Menu *root = (Menu*)item->getRoot();
					const wchar_t *key = child->getKey();

					this->index = -1;
					this->invalidate();

					if(root){
						root->popupClose();
					}else{
						while(item->getParent()!=(MenuItem*)NULL) item = item->getParent();
						item->popupClose();
					}

					if(child->onMenuClick) child->onMenuClick->Event(this, key);
					if(item->onMenuClick) item->onMenuClick->Event(this, key);
					if(root && root->onMenuClick) root->onMenuClick->Event(this, key);
				}
			}
			if(this->state!=prev) this->invalidate();
			break;}
		case WM_MOUSEMOVE:{
			MenuItem *item = (MenuItem*)this->item;
			POINTS pt = MAKEPOINTS(lParam);

			int visible = 0;
			for(int i=0; i<item->getChildCount(); i++){
				if( item->getChild(i)->popupVisible()>0 ){
					visible = 1;
					break;
				}
			}

			if(GetCapture()!=hWnd) SetCapture(hWnd);
			if((pt.x<0 || pt.y<0 || pt.x>=this->getWidth() || pt.y>=this->getHeight()) && visible==0){
				Menu *menu = (Menu*)item->getRoot();

				ReleaseCapture();
				if(menu) SetCapture(menu->getHWND());
				
				this->index = -1;
				this->invalidate();
				break;
			}
			if(item->popupTest()==1){
				ReleaseCapture();
			}

			int h=0, y=0;
			HDC hDC = GetDC(hWnd);
			HFONT font = (HFONT)SelectObject(hDC, this->getFont());
				int prev = this->index;
				this->index = -1;

				for(int i=0; i<item->getChildCount(); i++){
					const wchar_t *text = item->getChild(i)->getText();
					SIZE sz;

					if(item->getChild(i)->getChildCount()==0 && wcslen(text)==1 && text[0]==L'-') {
						sz.cy = -3;
					}else{
						GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
					}
					if( pt.y>=y && pt.y<h+sz.cy+8 && item->getChild(i)->getEnabled()>0 ){
						this->index = i;
						if(sz.cy<0) this->index = -2;
						y = h;
						break;
					}

					h += sz.cy+8;
				}
			SelectObject(hDC, font);
			ReleaseDC(hWnd, hDC);

			if(this->index!=prev){
				if(item->popupVisible()>0 && this->index!=-1){
					if(this->index==-2){
						if(prev>=0) item->getChild(prev)->popupClose();
						this->index = -1;
					}else{
						MenuItem *child = item->getChild(this->index);
						POINT pt = {this->getWidth(), y};
						ClientToScreen(this->hWnd, &pt);

						if(prev>=0) item->getChild(prev)->popupClose();
						if(child->getChildCount()>0) child->popupShow(pt.x-1, pt.y);
					}
				}
				this->invalidate();
			}
			break;}
		case WM_PAINT:{
			PAINTSTRUCT ps;
			HDC hDC = BeginPaint(hWnd, &ps);
			HFONT font = (HFONT)SelectObject(hDC, this->hFont);
				RECT rc;
				HBRUSH hbr = CreateSolidBrush(this->activeBackColor);
					GetClientRect(this->hWnd, &rc);
					FillRect(hDC, &rc, hbr);
				DeleteObject(hbr);
				
				hbr = CreateSolidBrush(this->backColor);
					rc.left++; rc.top++; rc.right--; rc.bottom--;
					FillRect(hDC, &rc, hbr);
				DeleteObject(hbr);
				
				SetBkMode(hDC, TRANSPARENT);

				MenuItem *item = (MenuItem*)this->item;
				int y = 0, w = rc.right+1;

				for(int i=0; i<item->getChildCount(); i++){
					MenuItem *child = item->getChild(i);
					const wchar_t *text = child->getText();

					int bc = this->backColor;
					if((state>0 && index==i) || child->popupVisible()>0){
						bc = this->activeBackColor;
					}else if(index==i){
						bc = this->hoverColor;
					}

					if(child->getEnabled()>0)
						SetTextColor(hDC, this->textColor);
					else
						SetTextColor(hDC, this->activeBackColor);

					if( child->getChildCount()>0 ){
						wchar_t *ttext = new wchar_t[wcslen(text)+4];
							wcscpy_s(ttext, wcslen(text)+4, text);
							wcscat_s(ttext, wcslen(text)+4, L"  \x25B8");

							SIZE sz;
							GetTextExtentPoint32(hDC, ttext, wcslen(ttext), &sz);

							SetRect(&rc, 1, 1+y, w-1, 1+y+sz.cy+8);
							hbr = CreateSolidBrush(bc);
								FillRect(hDC, &rc, hbr);
							DeleteObject(hbr);

							SetRect(&rc, 7, 1+y, w-7, 1+y+sz.cy+8);
							DrawText(hDC, ttext, wcslen(ttext), &rc, DT_VCENTER | DT_LEFT | DT_SINGLELINE);
						delete[] ttext;

						y += sz.cy+8;
					}else{
						if( wcslen(text)==1 && text[0]==L'-' ){
							SetRect(&rc, 4, 1+y+1, w-4, 1+y+2);

							hbr = CreateSolidBrush(this->activeBackColor);
								FillRect(hDC, &rc, hbr);
							DeleteObject(hbr);

							y += 3;
						}else{
							SIZE sz;
							GetTextExtentPoint32(hDC, text, wcslen(text), &sz);

							SetRect(&rc, 1, 1+y, w-1, 1+y+sz.cy+8);
							hbr = CreateSolidBrush(bc);
								FillRect(hDC, &rc, hbr);
							DeleteObject(hbr);

							SetRect(&rc, 7, 1+y, w-7, 1+y+sz.cy+8);
							DrawText(hDC, text, wcslen(text), &rc, DT_VCENTER | DT_LEFT | DT_SINGLELINE);

							y += sz.cy+8;
						}
					}
				}
			SelectObject(hDC, font);
			EndPaint(hWnd, &ps);
			return 0;}
	}
	return GUIWindow::handleMessage(hWnd, Msg, wParam, lParam);
}
