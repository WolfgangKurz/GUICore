/*
	GUIWidgets - Menu
	 The default widgets for use in GUICore.
	 author: SNOWALiCE, Yeoubi Project
	 homepage: http://snowalice.net/ http://yeou.bi/

	Menu class, require Button class
*/

#include "MenuItem.hpp"
#include "Menu.hpp"

Menu::Menu() : GUIWidget(0, 0, 0, 0){
	this->backColor = 0x000000;
	this->activeBackColor = 0x444444;
	this->textColor = 0xFFFFFF;

	this->index = -1;
	this->state = 0;

	this->childCount = 0;
	this->childs = (MenuItem**)NULL;

	this->onMenuClick = (GUIMenuEventP)NULL;
}
Menu::Menu(int x, int y, int width, int height) : GUIWidget(x, y, width, height){
	this->backColor = 0x000000;
	this->activeBackColor = 0x444444;
	this->textColor = 0xFFFFFF;

	this->index = -1;
	this->state = 0;

	this->childCount = 0;
	this->childs = (MenuItem**)NULL;

	this->onMenuClick = (GUIMenuEventP)NULL;
}
Menu::~Menu(){
	if(this->childs!=(MenuItem**)NULL){
		for(int i=0; i<this->childCount; i++)
			delete this->childs[i];
		delete[] this->childs;
	}

	if(this->onMenuClick) delete this->onMenuClick;
}

Menu* Menu::setFont(const wchar_t *fontName, int fontSize, int weight){
	for(int i=0; i<this->childCount; i++) this->childs[i]->setFont(fontName, fontSize, weight);
	GUIWidget::setFont(fontName, fontSize, weight);
	this->invalidate();
	return this;
}
Menu* Menu::setFont(HFONT font){
	for(int i=0; i<this->childCount; i++) this->childs[i]->setFont(font);
	GUIWidget::setFont(font);
	this->invalidate();
	return this;
}

Menu* Menu::invalidate(){
	GUIWidget::invalidate();
	return this;
}

Menu* Menu::move_center(){
	GUIWidget::move_center();
	return this;
}
Menu* Menu::move(int x, int y){
	GUIWidget::move(x, y);
	return this;
}
Menu* Menu::resize(int width, int height){
	GUIWidget::resize(width, height);
	this->invalidate();
	return this;
}

Menu* Menu::show(){
	GUIWidget::show();
	return this;
}
Menu* Menu::hide(){
	GUIWidget::hide();
	return this;
}

int Menu::getChildCount(){
	return this->childCount;
}
MenuItem* Menu::getChild(int index){
	if(index<0 || index>=this->childCount) return (MenuItem*)NULL;
	return this->childs[index];
}

MenuItem* Menu::addChild(wchar_t *key, wchar_t *text){
	MenuItem **copy = new MenuItem*[this->childCount+1];
	MenuItem *item = new MenuItem(key, text);

	if(this->childs!=(MenuItem**)NULL){
		memcpy((void*)copy, this->childs, sizeof(MenuItem*)*this->childCount);
		delete[] this->childs;
	}

	item->setFont(this->getFont())
		->setBackColor(this->getBackColor())
		->setActiveBackColor(this->getActiveBackColor())
		->setHoverColor(this->getHoverColor())
		->setTextColor(this->getTextColor())
		->setBorderColor(this->getActiveBackColor())
		->setRoot(this);

	copy[this->childCount] = item;
	this->childCount++;
	this->childs = copy;

	this->invalidate();
	return item;
}
MenuItem* Menu::addChild(wchar_t *key, wchar_t *text, int index){
	if(index<0 || index>this->childCount) return (MenuItem*)NULL;

	MenuItem **copy = new MenuItem*[this->childCount+1];
	MenuItem *item = new MenuItem(key, text);

	if(index>0) memcpy(copy, this->childs, sizeof(MenuItem*)*index);
	if(index<this->childCount) memcpy(&copy[index+1], this->childs+index, sizeof(MenuItem*)*(this->childCount-index));

	if(this->childs!=(MenuItem**)NULL) delete[] this->childs;

	item->setFont(this->getFont())
		->setBackColor(this->getBackColor())
		->setActiveBackColor(this->getActiveBackColor())
		->setHoverColor(this->getHoverColor())
		->setTextColor(this->getTextColor())
		->setBorderColor(this->getActiveBackColor())
		->setRoot(this);

	copy[index] = item;
	this->childCount++;
	this->childs = copy;

	this->invalidate();
	return item;
}
Menu* Menu::removeChild(int index){
	if(index<0 || index>=this->childCount) return this;

	MenuItem **copy = new MenuItem*[this->childCount-1];

	if(index>0) memcpy(copy, this->childs, sizeof(MenuItem*)*index);
	memcpy(copy+index, this->childs+index+1, sizeof(MenuItem*)*(this->childCount-index-1));

	delete[] this->childs;

	this->childCount--;
	this->childs = copy;

	this->invalidate();
	return this;
}

Menu* Menu::setBackColor(int color){
	this->backColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setBackColor(color);
	return this;
}
int Menu::getBackColor(){
	return this->backColor;
}

Menu* Menu::setActiveBackColor(int color){
	this->activeBackColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setActiveBackColor(color);
	return this;
}
int Menu::getActiveBackColor(){
	return this->activeBackColor;
}

Menu* Menu::setHoverColor(int color){
	this->hoverColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setHoverColor(color);
	return this;
}
int Menu::getHoverColor(){
	return this->hoverColor;
}

Menu* Menu::setTextColor(int color){
	this->textColor = color;
	for(int i=0; i<this->childCount; i++) this->childs[i]->setTextColor(color);
	return this;
}
int Menu::getTextColor(){
	return this->textColor;
}

Menu* Menu::popupClose(){
	for(int i=0; i<this->childCount; i++)
		this->childs[i]->popupClose();
	this->index = -1;
	this->invalidate();
	return this;
}
int Menu::popupTest(){
	for(int i=0; i<this->childCount; i++)
		if(this->childs[i]->popupTest()>0) return 1;
	return 0;
}
int Menu::popupCheck(){
	for(int i=0; i<this->childCount; i++)
		this->childs[i]->popupCheck();
	return 0;
}
int Menu::popupVisible(){
	for(int i=0; i<this->childCount; i++)
		if(this->childs[i]->popupVisible())
			return 1;
	return 0;
}

LRESULT Menu::handleMessage(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam){
	switch(Msg){
		case WM_PAINT:{
			PAINTSTRUCT ps;
			HDC hDC = BeginPaint(hWnd, &ps);
				HBRUSH hbr;
				RECT rc;
				GetClientRect(hWnd, &rc);

				hbr = CreateSolidBrush(this->backColor);
					SetBkMode(hDC, TRANSPARENT);
					FillRect(hDC, &rc, hbr);
				DeleteObject(hbr);

				HFONT font = (HFONT)SelectObject(hDC, this->getFont());
					int w=0;
					for(int i=0; i<this->childCount; i++){
						MenuItem *child = this->childs[i];
						const wchar_t *text = child->getText();
						SIZE sz;

						if(child->getEnabled()==0)
							SetTextColor(hDC, this->activeBackColor);
						else
							SetTextColor(hDC, this->textColor);

						GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
						SetRect(&rc, w, 0, w+sz.cx+20, this->getHeight());

						int bc = this->backColor;
						if((state>0 && index==i) || child->popupVisible()>0){
							bc = this->activeBackColor;
						}else if(index==i){
							bc = this->hoverColor;
						}

						hbr = CreateSolidBrush(bc);
							FillRect(hDC, &rc, hbr);
						DeleteObject(hbr);

						DrawText(hDC, text, wcslen(text), &rc, DT_CENTER | DT_VCENTER| DT_SINGLELINE);

						w += sz.cx+20;
					}
				SelectObject(hDC, font);
			EndPaint(hWnd, &ps);
			return 0;}
		case WM_LBUTTONDOWN:{
			POINTS pts = MAKEPOINTS(lParam);
			int prev = this->state;
			this->state = 0;

			if(pts.x<0 || pts.y<0 || pts.x>=this->getWidth() || pts.y>=this->getHeight()){
				ReleaseCapture();

				if( this->popupTest()==0 ){
					this->index = -1;
					this->invalidate();
					this->popupClose();
				}
				break;
			}

			if(this->index>=0){
				this->state = 1;

				if(this->childs[this->index]->getChildCount()>0){
					int x = 0;
					HDC hDC = GetDC(hWnd);
					HFONT font = (HFONT)SelectObject(hDC, this->getFont());
						for(int i=0; i<this->index; i++){
							const wchar_t *text = this->childs[i]->getText();
							SIZE sz;

							GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
							x += sz.cx+20;
						}

						const wchar_t *text = this->childs[this->index]->getText();
						SIZE sz;
						GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
					SelectObject(hDC, font);
					ReleaseDC(hWnd, hDC);

					POINT pt = {x, this->getHeight()};
					ClientToScreen(this->hWnd, &pt);

					MenuItem *child = this->childs[this->index];
					if(child->popupVisible()>0)
						child->popupClose();
					else
						child->popupShow(pt.x, pt.y);
				}
			}else{
				this->invalidate();
				this->popupClose();
				break;
			}

			if(this->state!=prev) this->invalidate();
			break;}
		case WM_LBUTTONUP:{
			int prev = this->state;
			this->state = 0;
			if(this->index>=0 && this->childs[this->index]->getChildCount()==0){
				if(this->childs[this->index]->onMenuClick) this->childs[this->index]->onMenuClick->Event(this, this->childs[this->index]->getKey());
				if(this->onMenuClick) this->onMenuClick->Event(this, this->childs[this->index]->getKey());

				this->index = -1;
				this->invalidate();
			}
			if(this->state!=prev) this->invalidate();
			break;}
		case WM_MOUSEMOVE:{
			POINTS pt = MAKEPOINTS(lParam);

			int visible = 0;
			for(int i=0; i<this->childCount; i++){
				if( this->childs[i]->popupVisible()>0 ){
					visible = 1;
					break;
				}
			}

			if(GetCapture()!=hWnd) SetCapture(hWnd);
			if(pt.x<0 || pt.y<0 || pt.x>=this->getWidth() || pt.y>=this->getHeight()){
				if(visible==0){
					ReleaseCapture();
					this->index = -1;
					this->invalidate();
					break;
				}
			}
			if(this->popupTest()>0){
				ReleaseCapture();
			}

			int w=0, x=0;
			HDC hDC = GetDC(hWnd);
			HFONT font = (HFONT)SelectObject(hDC, this->getFont());
				int prev = this->index;
				this->index = -1;

				if(pt.y>=0 && pt.y<this->getHeight()){
					for(int i=0; i<this->childCount; i++){
						const wchar_t *text = this->childs[i]->getText();
						SIZE sz;

						GetTextExtentPoint32(hDC, text, wcslen(text), &sz);
						if( pt.x>=w && pt.x<w+sz.cx+20 && this->childs[i]->getEnabled()>0 ){
							this->index = i;
							x = w;
							break;
						}

						w += sz.cx+20;
					}
				}
			SelectObject(hDC, font);
			ReleaseDC(hWnd, hDC);

			if(this->index!=prev){
				if(this->popupVisible()>0 && this->index>=0){
					MenuItem *child = this->childs[this->index];
					POINT pt = {x, this->getHeight()};
					ClientToScreen(this->hWnd, &pt);

					for(int i=0; i<this->childCount; i++)
						if(i!=this->index)
							this->childs[i]->popupClose();
					if(child->getChildCount()>0) child->popupShow(pt.x, pt.y);
				}
				this->invalidate();
			}
			break;}
	}
	return GUIWidget::handleMessage(hWnd, Msg, wParam, lParam);
}
