/*
	GUIWidgets - MenuItem
	 The default widgets for use in GUICore.
	 author: WolfgangKurz

	Item of Menu class
	need to use Menu
*/

#pragma once

#include "GUIWidget.hpp"
#include "GUIWindow.hpp"

#include "MenuPopup.hpp"

#ifdef __GNUC__
	#define __DEPRECATED_MSVC
	#define __DEPRECATED_GNUC __attribute__((deprecated))
#elif defined(_MSC_VER)
	#define __DEPRECATED_MSVC __declspec(deprecated("Menu is deprecated. Use LegacyMenu instead."))
	#define __DEPRECATED_GNUC
#endif

class __DEPRECATED_MSVC MenuItem{
private:
	MenuItem *parent;
	GUIObject *root;
	MenuPopup *popup;

	int backColor, activeBackColor;
	int hoverColor, textColor;
	int enabled;

	int childCount;
	MenuItem **childs;

	wchar_t *key;
	wchar_t *text;

	void prepare();

public:
	MenuItem(wchar_t *key, wchar_t *text);
	MenuItem(wchar_t *key, wchar_t *text, MenuItem *parent);
	~MenuItem();

	MenuItem* setFont(const wchar_t *fontName, int fontSize, int weight);
	MenuItem* setFont(HFONT font);
	HFONT getFont();

	MenuItem* invalidate();

	MenuItem* setEnabled(int enabled);
	int getEnabled();

	MenuItem* setBackColor(int color);
	int getBackColor();

	MenuItem* setActiveBackColor(int color);
	int getActiveBackColor();

	MenuItem* setHoverColor(int color);
	int getHoverColor();

	MenuItem* setTextColor(int color);
	int getTextColor();

	MenuItem* setBorderColor(int color);
	int getBorderColor();

	MenuItem* setRoot(GUIObject *root);
	GUIObject* getRoot();

	MenuItem* getParent();

	int getChildCount();
	MenuItem* getChild(int index);

	MenuItem* addChild(wchar_t *key, wchar_t *text);
	MenuItem* addChild(wchar_t *key, wchar_t *text, int index);
	MenuItem* removeChild(int index);

	const wchar_t* getKey();
	const wchar_t* getText();
	MenuItem* setText(wchar_t *text);

	MenuItem* popupShow(int x, int y);
	MenuItem* popupClose();
	int popupVisible();
	int popupTest();
	int popupCheck();

	GUIMenuEventP onMenuClick; // GUIMenuEvent::Event(GUIObject *sender, const wchar_t *key)
} __DEPRECATED_GNUC;
