/*
	GUIWidgets - MenuPopup
	 The default widgets for use in GUICore.
	 author: WolfgangKurz

	Popup window of Menu
*/

#pragma once

#include "GUIWindow.hpp"

#ifdef __GNUC__
	#define __DEPRECATED_MSVC
	#define __DEPRECATED_GNUC __attribute__((deprecated))
#elif defined(_MSC_VER)
	#define __DEPRECATED_MSVC __declspec(deprecated("Menu is deprecated. Use LegacyMenu instead."))
	#define __DEPRECATED_GNUC
#endif

class __DEPRECATED_MSVC MenuPopup : public GUIWindow {
private:
	void *item;

	int backColor, activeBackColor;
	int hoverColor, textColor;
	int borderColor;
	int index, state;

public:
	MenuPopup(void *item);
	void* getItem();

	MenuPopup* setBackColor(int color);
	int getBackColor();

	MenuPopup* setActiveBackColor(int color);
	int getActiveBackColor();

	MenuPopup* setHoverColor(int color);
	int getHoverColor();

	MenuPopup* setTextColor(int color);
	int getTextColor();

	MenuPopup* setBorderColor(int color);
	int getBorderColor();

	virtual LRESULT handleMessage(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
} __DEPRECATED_GNUC;
