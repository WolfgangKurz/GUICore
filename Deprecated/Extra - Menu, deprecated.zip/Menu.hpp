/*
	GUIWidgets - Menu
	 The default widgets for use in GUICore.
	 author: SNOWALiCE, Yeoubi Project
	 homepage: http://snowalice.net/ http://yeou.bi/

	Menu class
*/

#pragma once

#include "GUIWidget.hpp"
#include "MenuItem.hpp"

#ifdef __GNUC__
	#define __DEPRECATED_MSVC
	#define __DEPRECATED_GNUC __attribute__((deprecated))
#elif defined(_MSC_VER)
	#define __DEPRECATED_MSVC __declspec(deprecated("Menu is deprecated. Use LegacyMenu instead."))
	#define __DEPRECATED_GNUC
#endif

class __DEPRECATED_MSVC Menu : public GUIWidget{
private:
	int backColor, activeBackColor;
	int hoverColor, textColor;
	int childCount;
	int index, state;
	MenuItem **childs;

public:
	Menu();
	Menu(int x, int y, int width, int height);
	virtual ~Menu();

	virtual Menu* setFont(const wchar_t *fontName, int fontSize, int weight);
	virtual Menu* setFont(HFONT font);

	virtual Menu* invalidate();

	virtual Menu* move_center();
	virtual Menu* move(int x, int y);
	virtual Menu* resize(int width, int height);

	virtual Menu* show();
	virtual Menu* hide();

	Menu* setBackColor(int color);
	int getBackColor();

	Menu* setActiveBackColor(int color);
	int getActiveBackColor();

	Menu* setHoverColor(int color);
	int getHoverColor();

	Menu* setTextColor(int color);
	int getTextColor();

	int getChildCount();
	MenuItem* getChild(int index);
	
	MenuItem* addChild(wchar_t *key, wchar_t *text);
	MenuItem* addChild(wchar_t *key, wchar_t *text, int index);
	Menu* removeChild(int index);

	Menu* popupClose();
	int popupTest();
	int popupCheck();
	int popupVisible();

	virtual LRESULT handleMessage(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

	GUIMenuEventP onMenuClick; // GUIMenuEvent::Event(GUIObject *sender, const wchar_t *key)
} __DEPRECATED_GNUC;
